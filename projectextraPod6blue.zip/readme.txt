Name: 1)Malhar Mane 2)Parth Korat 3)Hengxi Liang

UCInetID: 1)mmane 2)pkorat 3)hengxil

Name of the code: Calculator day and age

Explanation: There are 2 GUI's in this calculator. The user can select any 1 and do all the calculations.
	This calculator helps you figure out every thing possible and is better than windows calculator.
	Use this calculator and make your calculations simpler

Code successful or not: Successful

Difficulty: 7

None

Note: as per the email sent to professor we discussed on 5 points per person. but we have worked on the two gui's and window resizes
and as talked with the professor these would give extra points so we expect around 8 to 10 points